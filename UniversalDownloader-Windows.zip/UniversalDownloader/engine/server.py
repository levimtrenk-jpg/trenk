"""
שרת ה-API של המנוע (FastAPI). מאזין רק ל-127.0.0.1.
רק התוסף שה-ID שלו ב-config.json יכול לפנות אליו מהדפדפן; כל Origin אחר נדחה.
ההפעלה הרגילה היא דרך main.pyw (שרת + אייקון במגש).
"""
import logging
import os
import subprocess
import sys
from pathlib import Path

import yt_dlp.version
from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel

import config
import downloader

VERSION = "2.0.0"
log = logging.getLogger("engine.server")

app = FastAPI(title="Universal Downloader Engine", version=VERSION, docs_url=None, redoc_url=None)

# main.pyw מחבר כאן פונקציה שמפעילה את המנוע מחדש (אחרי עדכון)
request_restart = None


# ---------- אבטחה: Host + Origin ----------

@app.middleware("http")
async def guard(request: Request, call_next):
    host = request.headers.get("host", "")
    # הגנה מ-DNS rebinding: רק כתובת מקומית
    if host.rsplit(":", 1)[0] not in ("127.0.0.1", "localhost"):
        return JSONResponse({"detail": "forbidden host"}, status_code=403)

    origin = request.headers.get("origin")
    if origin is None:
        # בקשה שלא מדף אינטרנט (curl, סקריפט מקומי). דפדפן שולח Origin בכל בקשה cross-origin.
        return await call_next(request)
    if origin not in config.allowed_origins():
        log.warning("rejected origin %s %s %s", origin, request.method, request.url.path)
        return JSONResponse({"detail": "origin not allowed"}, status_code=403)

    cors = {
        "Access-Control-Allow-Origin": origin,
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Private-Network": "true",
        "Vary": "Origin",
    }
    if request.method == "OPTIONS":
        return Response(status_code=204, headers={**cors, "Access-Control-Max-Age": "600"})
    if not request.url.path.startswith("/jobs/"):  # /jobs נקרא כל 700ms, לא ממלאים בו את הלוג
        log.info("extension %s %s", request.method, request.url.path)
    response = await call_next(request)
    response.headers.update(cors)
    return response


# ---------- endpoints ----------

@app.get("/health")
def health():
    return {"ok": True, "version": VERSION, "ytdlp_version": yt_dlp.version.__version__,
            "download_dir": str(config.download_dir())}


@app.get("/formats")
def formats(url: str):
    try:
        return downloader.probe(url)
    except downloader.DownloadFailed as e:
        raise HTTPException(400, str(e)) from e


class DownloadRequest(BaseModel):
    url: str
    format_id: str


@app.post("/download")
def download(req: DownloadRequest):
    try:
        return {"job_id": downloader.start(req.url, req.format_id)}
    except downloader.DownloadFailed as e:
        raise HTTPException(400, str(e)) from e


@app.get("/jobs/{job_id}")
def job_status(job_id: str):
    job = downloader.jobs.get(job_id)
    if not job:
        raise HTTPException(404, "משימה לא נמצאה")
    return job


class OpenRequest(BaseModel):
    job_id: str | None = None


@app.post("/open")
def open_folder(req: OpenRequest):
    """פותח את תיקיית ההורדות. עם job_id: פותח את התיקייה ומסמן את הקובץ."""
    folder = config.download_dir().resolve()
    job = downloader.jobs.get(req.job_id) if req.job_id else None
    path = Path(job["file_path"]).resolve() if job and job.get("file_path") else None
    if path and path.is_file() and folder in path.parents:
        subprocess.Popen(["explorer", f"/select,{path}"])
    else:
        os.startfile(folder)
    return {"ok": True}


def active_jobs() -> int:
    return sum(j["status"] in ("queued", "downloading", "processing") for j in list(downloader.jobs.values()))


def _python_exe() -> str:
    # pythonw לא מחזיר פלט; ל-pip משתמשים ב-python.exe שלידו
    exe = Path(sys.executable)
    return str(exe.with_name("python.exe") if exe.name.lower() == "pythonw.exe" else exe)


def update_ytdlp() -> dict:
    """pip install -U yt-dlp. מחזיר את הגרסה לפני ואחרי."""
    no_window = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    before = yt_dlp.version.__version__
    proc = subprocess.run([_python_exe(), "-m", "pip", "install", "-q", "-U", "yt-dlp[default,curl-cffi]"],
                          capture_output=True, text=True, timeout=300, creationflags=no_window)
    after = subprocess.run([_python_exe(), "-c", "import yt_dlp.version as v; print(v.__version__)"],
                           capture_output=True, text=True, timeout=60, creationflags=no_window).stdout.strip()
    if proc.returncode != 0:
        log.error("pip failed: %s", proc.stderr)
    return {"ok": proc.returncode == 0, "before": before, "after": after or before,
            "error": proc.stderr.strip()[-500:] if proc.returncode else None}


@app.post("/update")
def update(background: BackgroundTasks):
    if active_jobs():
        raise HTTPException(409, "יש הורדות פעילות. נסה שוב כשהן יסתיימו.")
    result = update_ytdlp()
    result["restarting"] = bool(result["ok"] and request_restart)
    if result["restarting"]:
        background.add_task(request_restart)  # רץ אחרי שהתשובה נשלחה
    return result
