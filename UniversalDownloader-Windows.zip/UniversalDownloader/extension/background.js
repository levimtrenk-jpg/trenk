// כל התקשורת עם המנוע עוברת כאן. המנוע מקבל רק בקשות עם Origin של התוסף,
// ולכן ה-content scripts (שרצים עם ה-Origin של האתר) לא פונים אליו ישירות.
const ENGINE = "http://127.0.0.1:5123";

const TIMEOUTS = { health: 4000, formats: 120000, download: 15000, job: 10000, open: 10000, update: 330000 };

async function call(type, path, { method = "GET", body } = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUTS[type] || 15000);
  try {
    const res = await fetch(ENGINE + path, {
      method,
      signal: ctrl.signal,
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 403) {
      return { ok: false, error: `התוסף לא מורשה במנוע. הוסף את ה-ID ‏${chrome.runtime.id} ל-engine/config.json` };
    }
    if (!res.ok) return { ok: false, error: data.detail || `שגיאה ${res.status}` };
    return { ok: true, data };
  } catch (e) {
    if (e.name === "AbortError" && type !== "health") {
      return { ok: false, error: "המנוע לא ענה בזמן. נסה שוב." };
    }
    // fetch נכשל = אין מי שמאזין בפורט
    return { ok: false, down: true, error: "המנוע כבוי – הפעל אותו" };
  } finally {
    clearTimeout(timer);
  }
}

const handlers = {
  // ניסיון שני לפני שמכריזים שהמנוע כבוי (תקלה רגעית לא צריכה להציג הודעה מפחידה)
  health: async () => {
    const first = await call("health", "/health");
    if (first.ok || !first.down) return first;
    await new Promise((r) => setTimeout(r, 700));
    return call("health", "/health");
  },
  formats: (m) => call("formats", "/formats?url=" + encodeURIComponent(m.url)),
  download: (m) => call("download", "/download", { method: "POST", body: { url: m.url, format_id: m.format_id } }),
  job: (m) => call("job", "/jobs/" + encodeURIComponent(m.id)),
  open: (m) => call("open", "/open", { method: "POST", body: { job_id: m.job_id || null } }),
  update: () => call("update", "/update", { method: "POST" }),
};

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const handler = handlers[msg?.type];
  if (!handler) return false;
  handler(msg).then(sendResponse);
  return true; // תשובה אסינכרונית
});
