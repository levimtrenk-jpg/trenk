// חלון התוסף: סטטוס המנוע, תיקיית היעד, פתיחת התיקייה ועדכון yt-dlp.
const $ = (id) => document.getElementById(id);
const send = (msg) => chrome.runtime.sendMessage(msg);

$("extId").textContent = chrome.runtime.id;
$("extVersion").textContent = chrome.runtime.getManifest().version;

async function refresh() {
  const res = await send({ type: "health" });
  const ok = res?.ok;
  $("dot").className = "dot " + (ok ? "ok" : "bad");
  $("state").textContent = ok ? "המנוע פועל" : res?.down ? "המנוע כבוי – הפעל אותו" : res?.error || "שגיאה";
  $("versions").textContent = ok ? `מנוע ${res.data.version} · yt-dlp ${res.data.ytdlp_version}` : "";
  $("hint").hidden = !res?.down;
  $("dirBox").hidden = !ok;
  $("actions").hidden = !ok;
  if (ok) $("dir").textContent = res.data.download_dir || "";
  return ok;
}

$("openBtn").onclick = () => send({ type: "open" });

$("updateBtn").onclick = async () => {
  const btn = $("updateBtn");
  btn.disabled = true;
  $("note").textContent = "מעדכן את yt-dlp... (עד דקה)";
  const res = await send({ type: "update" });
  if (!res?.ok) {
    $("note").textContent = res?.error || "העדכון נכשל";
    btn.disabled = false;
    return;
  }
  const { before, after, restarting } = res.data;
  $("note").textContent = before === after ? `yt-dlp כבר מעודכן (${after}).` : `yt-dlp עודכן: ${before} ← ${after}.`;
  if (restarting) {
    $("note").textContent += " המנוע מופעל מחדש...";
    // מחכים שהמנוע יחזור (עד 30 שניות)
    for (let i = 0; i < 30; i++) {
      await new Promise((r) => setTimeout(r, 1000));
      if (await refresh()) {
        $("note").textContent = $("note").textContent.replace(" המנוע מופעל מחדש...", " המנוע חזר לפעול.");
        break;
      }
    }
  }
  btn.disabled = false;
};

refresh();
